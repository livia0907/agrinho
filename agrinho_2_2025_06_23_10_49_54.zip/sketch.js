let player;
let modo = "cidade"; // Alterna entre "cidade" e "campo"
let sustentabilidade = 100;
let progresso = 0;

function setup() {
  createCanvas(800, 600);
  player = new Player();
}

function draw() {
  background(220);

  if (modo === "cidade") {
    drawCidade();
  } else {
    drawCampo();
  }

  player.update();
  player.show();

  mostrarHUD();
}

function drawCidade() {
  background(180);
  fill(100);
  rect(0, 500, width, 100); // Rua
  fill(50, 50, 150);
  rect(100, 300, 100, 200); // Prédio
  fill(0, 255, 0);
  text("Cidade", 20, 20);
}

function drawCampo() {
  background(100, 200, 100);
  fill(139, 69, 19);
  rect(200, 400, 50, 200); // Árvore
  fill(34, 139, 34);
  ellipse(225, 400, 100, 100);
  fill(255);
  text("Campo", 20, 20);
}

function keyPressed() {
  if (keyCode === 9) { // TAB
    modo = (modo === "cidade") ? "campo" : "cidade";
  }

  if (key === ' ') {
    if (modo === "cidade") {
      progresso += 5;
      sustentabilidade -= 3;
    } else {
      sustentabilidade += 5;
      progresso -= 2;
    }
  }
}

function mostrarHUD() {
  fill(0);
  textSize(18);
  text("Sustentabilidade: " + sustentabilidade, 20, 60);
  text("Progresso Urbano: " + progresso, 20, 80);

  // Indicadores visuais
  fill(0, 200, 0);
  rect(20, 90, sustentabilidade * 2, 10);
  fill(0, 0, 200);
  rect(20, 110, progresso * 2, 10);
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 40;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 4;
    if (keyIsDown(RIGHT_ARROW)) this.x += 4;
    if (keyIsDown(UP_ARROW)) this.y -= 4;
    if (keyIsDown(DOWN_ARROW)) this.y += 4;
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  show() {
    fill(255, 200, 0);
    ellipse(this.x, this.y, this.size);
  }
}
